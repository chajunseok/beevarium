<script setup></script>

<template>
  <img
    class="stream-display"
    src="../../../assets/img/stream/stream-display.png"
    alt=""
  />
</template>

<style scoped>
.stream-display {
  width: 100%;
  height: 100%;
}
</style>
