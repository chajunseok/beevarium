<script setup></script>

<template>
  <div class="thumbnail">
    <p>StreamThumbnail</p>
    <div></div>
  </div>
</template>

<style scoped>
.thumbnail {
  border: 2px solid blue;
  border-radius: 10px;
  width: 100%;
  height: 70px;
  padding: 10px;
}
</style>
