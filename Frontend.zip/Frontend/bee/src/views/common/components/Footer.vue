<script setup></script>

<template>
  <div class="footer-container">
    <h1>Footer</h1>
  </div>
</template>

<style scoped></style>
